# Iron Man 7

## Citations
1. Normalize reset stylesheet, by Nicolas Gallagher. URL: https://necolas.github.io/normalize.css/8.0.1/normalize.css; Github URL: https://github.com/necolas/normalize.css/; Date accessed: 1 Dec 2021

2. 

## To Do
1. Add styling to body of menu, order, finish merging about us css to main

2. make sure css works properly on mobile

3. make sure js works after css finished

4. add citations to code and readme

5. validate