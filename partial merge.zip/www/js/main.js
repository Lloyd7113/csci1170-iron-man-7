/*toggle for primary nav*/
document.getElementById("drop-menu").onclick = function() {
    var mNav = document.getElementById("main-nav");
    if (mNav.style.display == "none") {
        mNav.style.display = "flex";
    }else {
        mNav.style.display = "none";
    }
}

document.getElementById("place-order").onClick = submit();

function submit(){
    let goodSubmission = true;
    let content = {
        mainItem: document.getElementById("main-item").value,
        sideItem: document.getElementById("side-item").value,
        desertItem: document.getElementById("desert").value
    }
    console.log(JSON.stringify(content));

    for(sectionKey in content){
        if(!verifyInput(sectionKey)){
            goodSubmission = false;
        }
    }

    if(goodSubmission){

        let newSection = document.createElement("section");
        let sectionHeader = document.createElement("h3");
        sectionHeader.innerHTML = "Order Summary:";
        newSection.appendChild(sectionHeader);

        let newUl = document.createElement("ul");
        for(key in content){
           let newLi = document.createElement("li");
           newLi.innerHTML = content[key];
           newUl.appendChild(newLi);
        }


        newSection.appendChild(newUl);
        document.getElementById("pg-main-content").appendChild(newSection);
    }
    else {
        alert("Invalid order entry!");
    }

}

function verifyInput(contentKey){
    let menuItems = {
            Item1: "Beef Tacos",
            Item2: "Chicken Tacos",
            Item3: "King Taco",
            Item4: "Cheese Nachos",
            Item5: "Cheese and Bacon Nachos",
            Item6: "Works Nachos",
            Item7: "Tortillas",
            Item8: "Chimichangas",
            Item9: "Burritos"
    }
    let isMenuItem = false;

    for(key in menuItems){
        if(content[contentKey] == key){
            isMenuItem = true;
        }
    }
    return isMenuItem;
}